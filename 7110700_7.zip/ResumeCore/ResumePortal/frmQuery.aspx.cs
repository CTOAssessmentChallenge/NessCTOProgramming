﻿using Microsoft.Practices.ServiceLocation;
using ResumePortal.Model;
using SolrNet;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ResumePortal
{
    public partial class frmQuery : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (ddl_Field.SelectedItem == null)
            {
                ddl_Field.Items.Clear();

                ddl_Field.Items.Add(new ListItem() { Text = "Id", Value = "id" });
                ddl_Field.Items.Add(new ListItem() { Text = "FileName", Value = "fileName" });
                ddl_Field.Items.Add(new ListItem() { Text = "UploadedBy", Value = "uploadedBy" });
                ddl_Field.Items.Add(new ListItem() { Text = "UploadedDate", Value = "uploadedDate" });
                ddl_Field.Items.Add(new ListItem() { Text = "Data", Value = "data" });
            }

            grid_resumes.Visible = false;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            ISolrOperations<Resume> solr = ServiceLocator.Current.GetInstance<ISolrOperations<Resume>>();

            if (ddl_Field.SelectedItem.Value != null && !string.IsNullOrEmpty(txt_Value.Text))
            {
                string field = ddl_Field.SelectedItem.Value, value = txt_Value.Text;
                var results = solr.Query(new SolrQueryByField(field, value));

                List<ResumeDTO> list = new List<ResumeDTO>();

                foreach (var result in results)
                {
                    ResumeDTO item = new ResumeDTO(result);
                    list.Add(item);
                }

                grid_resumes.DataSource = list;
                grid_resumes.Visible = true;
                grid_resumes.AutoGenerateColumns = true;
                grid_resumes.DataBind();
            }

        }

        private string NewId()
        {
            Guid id = new Guid();
            return id.ToString();
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            try
            {
                HttpPostedFile file = fileUpload.PostedFile;

                file.SaveAs(Server.MapPath("Upload") + "/" + file.FileName);

                Resume newresume = new Resume() { FileName = file.FileName, Id = NewId(), UploadedBy = "User", UploadedDate = DateTime.Now };

                ISolrOperations<Resume> solr = ServiceLocator.Current.GetInstance<ISolrOperations<Resume>>();
                using (var indexFile = File.OpenRead(Server.MapPath("Upload") + "/" + file.FileName))
                {
                    var response = solr.Extract(new ExtractParameters(indexFile, "doc1")
                    {
                        ExtractOnly = true,
                        ExtractFormat = ExtractFormat.Text,
                    });

                    newresume.Data = response.Content;

                }

                solr.Add(newresume);
                solr.Commit();
            }
            catch (Exception ex)
            {

            }
        }
    }
}