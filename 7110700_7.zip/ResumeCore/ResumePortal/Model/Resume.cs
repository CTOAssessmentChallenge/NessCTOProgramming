﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SolrNet.Attributes;

namespace ResumePortal.Model
{
    public class Resume
    {
        [SolrUniqueKey("id")]
        public string Id { get; set; }

        [SolrField("fileName")]
        public string FileName { get; set; }

        [SolrField("uploadedBy")]
        public string UploadedBy { get; set; }

        [SolrField("uploadedDate")]
        public DateTime UploadedDate { get; set; }

        [SolrField("data")]
        public string Data { get; set; }
    }
}