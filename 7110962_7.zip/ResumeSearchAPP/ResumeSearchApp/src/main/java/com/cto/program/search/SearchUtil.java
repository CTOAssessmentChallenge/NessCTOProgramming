package com.cto.program.search;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author vishnudasl
 * 
 */
public class SearchUtil {

	/**
	 * @param propName
	 * @return
	 */
	public static String getProperty(String propName) {
		Properties prop = new Properties();
		InputStream input = null;
		String propValue = null;
		try {

			String filename = "config.properties";
			input = SearchUtil.class.getClassLoader().getResourceAsStream(
					filename);
			if (input == null) {
				System.out.println("Sorry, unable to find " + filename);
			}
			prop.load(input);

			propValue = prop.getProperty(propName);
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return propValue;
	}

}
