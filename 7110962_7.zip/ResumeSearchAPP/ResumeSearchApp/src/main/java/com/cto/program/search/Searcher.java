package com.cto.program.search;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.springframework.stereotype.Component;

/**
 * @author vishnudasl
 * 
 */
@Component
public class Searcher {

	/**
	 * @param queryString
	 * @return
	 */
	public List<FileItem> searchResumes(String queryString) {
		String INDEX_DIR = SearchUtil.getProperty("INDEX_DIR");
		List<FileItem> fileList = new ArrayList<FileItem>();
		StandardAnalyzer standardAnalyzer = new StandardAnalyzer();
		try {
			Directory directory = FSDirectory.open(Paths.get(INDEX_DIR));
			IndexReader reader = DirectoryReader.open(directory);

			IndexSearcher searcher = new IndexSearcher(reader);

			QueryParser parser = new QueryParser("content", standardAnalyzer);

			Query query = parser.parse(queryString);

			TopDocs results = searcher.search(query, 5);

			for (int i = 0; i < results.totalHits; i++) {
				Document doc = searcher.doc(results.scoreDocs[i].doc); // get
																		// the
																		// next
																		// document
				String url = doc.get("path"); // get its path field
				System.out.println("Found in :: " + url);
				FileItem item = new FileItem();
				item.setTitle(doc.get("title"));
				item.setFileUrl(url);
				fileList.add(item);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return fileList;
	}
}
