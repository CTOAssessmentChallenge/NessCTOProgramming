package com.cto.program.search;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author vishnudasl
 *
 */
@Controller
@RequestMapping("/")
public class FileController {
	private static final Logger logger = LoggerFactory
			.getLogger(FileController.class);
	@Autowired
	private IndexerService service;
	@Autowired
	private Searcher searcher;

	public FileController() {
		System.out.println(this.getClass().getSimpleName() + "created");
	}

	@RequestMapping(value = "upload.do", method = RequestMethod.POST)
	public ModelAndView uploadFile(@RequestParam("file") MultipartFile file) {
		String extension = null;
		String RESUME_DIR = SearchUtil.getProperty("RESUME_DIR");
		System.out.println(RESUME_DIR);

		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();

				// Creating the directory to store file
				File dir = new File(RESUME_DIR + File.separator);

				// Create the file on server
				File serverFile = new File(dir.getAbsolutePath()
						+ File.separator + file.getOriginalFilename());
				BufferedOutputStream stream = new BufferedOutputStream(
						new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();

				logger.info("Server File Location="
						+ serverFile.getAbsolutePath());

				if (file.getOriginalFilename().lastIndexOf(".") != -1
						&& file.getOriginalFilename().lastIndexOf(".") != 0)
					extension = file.getOriginalFilename().substring(
							file.getOriginalFilename().lastIndexOf(".") + 1);
				if ("pdf".equalsIgnoreCase(extension)) {
					System.out.println("indexing pdf");
					service.indexPDFFile(file.getOriginalFilename());
				} else if ("xls".equalsIgnoreCase(extension)
						|| "doc".equalsIgnoreCase(extension)
						|| "ppt".equalsIgnoreCase(extension)
						|| "xlsx".equalsIgnoreCase(extension)
						|| "docx".equalsIgnoreCase(extension)) {
					System.out.println("indexing ms office doc");
					service.docFileContentParser(extension,file.getOriginalFilename());
				} else {
					System.out.println("indexing text file");
					service.createTextIndex(file.getOriginalFilename());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return new ModelAndView("home", "msg", "Resume Uploaded");
	}

	@RequestMapping(value = "search.do", method = RequestMethod.POST)
	public ModelAndView search(@RequestParam("searchQuery") String searchQuery) {
		System.out.println("serach started" + searchQuery);
		List<FileItem> fileList=searcher.searchResumes(searchQuery);
		System.out.println("Results"+fileList.size());
		return new ModelAndView("home", "result", fileList);
	}
}
