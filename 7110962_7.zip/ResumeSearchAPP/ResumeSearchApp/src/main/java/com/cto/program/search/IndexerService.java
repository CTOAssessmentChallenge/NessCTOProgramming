package com.cto.program.search;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.nio.file.Paths;
import java.util.List;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.springframework.stereotype.Component;

/**
 * @author vishnudasl
 * 
 */
@Component
public class IndexerService {

	/**
	 * @param fileName
	 * @throws IOException
	 */
	public void createTextIndex(String fileName) throws IOException {
		String INDEX_DIR = SearchUtil.getProperty("INDEX_DIR");
		String RESUME_DIR = SearchUtil.getProperty("RESUME_DIR");
		StandardAnalyzer standardAnalyzer = new StandardAnalyzer();

		File file = new File(RESUME_DIR+"\\" + fileName);

		Directory directory = FSDirectory.open(Paths.get(INDEX_DIR));

		IndexWriterConfig config = new IndexWriterConfig(standardAnalyzer);

		config.setOpenMode(OpenMode.CREATE);

		// Create a writer

		IndexWriter writer = new IndexWriter(directory, config);

		Document document = new Document();

		try (BufferedReader br = new BufferedReader(new FileReader(RESUME_DIR+"\\"
				+ fileName))) {

			document.add(new TextField("content", br));
			document.add(new StringField("path", file.getPath(),
					Field.Store.YES));
			document.add(new StringField("title", fileName, Field.Store.YES));

			writer.addDocument(document);

			writer.close();

		} catch (IOException e) {

			e.printStackTrace();

		}

	}

	/**
	 * @param fileName
	 */
	public void indexPDFFile(String fileName) {
		String RESUME_DIR = SearchUtil.getProperty("RESUME_DIR");
		String contents = "";
		PDDocument doc = null;

		try {
			File file = new File(RESUME_DIR+"\\" + fileName);
			doc = PDDocument.load(file);
			PDFTextStripper stripper = new PDFTextStripper();
			stripper.setLineSeparator("\n");
			stripper.setStartPage(1);
			stripper.setEndPage(5);// this mean that it will index the first 5
									// pages only
			contents = stripper.getText(doc);
			indexFile(contents, fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param extension
	 * @param fileName
	 * @return
	 */
	public String docFileContentParser(String extension, String fileName) {
		String RESUME_DIR = SearchUtil.getProperty("RESUME_DIR");
		try {

			File file = new File(RESUME_DIR+"\\" + fileName);
			FileInputStream fis = new FileInputStream(file.getAbsolutePath());
			XWPFDocument document = new XWPFDocument(fis);

			List<XWPFParagraph> paragraphs = document.getParagraphs();
			StringBuffer bufString = new StringBuffer();
			System.out.println("Total no of paragraph " + paragraphs.size());

			for (XWPFParagraph para : paragraphs) {
				bufString.append(para.getText());
			}
			indexFile(bufString.toString(), fileName);

		} catch (Exception e) {
			System.out
					.println("document file cant be indexed" + e.getMessage());
		}
		return "";
	}

	/**
	 * @param contents
	 * @param fileName
	 */
	public void indexFile(String contents, String fileName) {
		StandardAnalyzer standardAnalyzer = new StandardAnalyzer();

		IndexWriterConfig config = new IndexWriterConfig(standardAnalyzer);
		config.setOpenMode(OpenMode.CREATE);
		String INDEX_DIR = SearchUtil.getProperty("INDEX_DIR");
		String RESUME_DIR = SearchUtil.getProperty("RESUME_DIR");

		try {
			Directory directory = FSDirectory.open(Paths.get(INDEX_DIR));

			IndexWriter writer = new IndexWriter(directory, config);
			File file = new File(RESUME_DIR+"\\" + fileName);
			Document document = new Document();
			Reader inputString = new StringReader(contents);

			BufferedReader content = new BufferedReader(inputString);
			document.add(new TextField("content", content));
			document.add(new StringField("path", file.getPath(),
					Field.Store.YES));
			document.add(new StringField("title", fileName, Field.Store.YES));
			writer.addDocument(document);

			writer.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
