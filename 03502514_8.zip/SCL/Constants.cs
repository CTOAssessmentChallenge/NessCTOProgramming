﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCL
{
  static class Constants
  {
    public static int PivotsCount = 200;  // count of most positive and most negative words used for evaluation
    public static int ProductsCount = 10; // count of most positive and most negative products in result set (best products / worst products)

    public static string ReviewParentTag = "review";
    public static string ReviewTextTag = "review_text";
    public static string TitleTag = "title";
    public static string ProductNameTag = "product_name";

    public static string PositiveFileName = "positive.review";
    public static string NegativeFileName = "negative.review";
    public static string UnlabeledFileName = "unlabeled.review";

    public static int TitleRelevanceFactor = 2; // words in titles are 2 x more important

    // list of most common words: https://en.wikipedia.org/wiki/Most_common_words_in_English, only first 50 implemented
    public static string[] MostCommonWords = new string[] {
      "the", "be", "to", "of", "and", "a", "in", "that", "have", "i", "it", "for", "not", "on", "with", "he", "as", "you", "do", "at",
      "this", "but", "his", "by", "from", "they", "we", "say", "her", "she", "or", "an", "will", "my", "one", "all", "would", "there",
      "their", "what", "so", "up", "out", "if", "about", "who", "get", "which", "go", "me" };
  }
}
