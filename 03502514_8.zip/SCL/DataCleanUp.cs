﻿using System;
using System.Text.RegularExpressions;

namespace SCL
{
  static class DataCleanUp
  {
    /// <summary>
    /// Clean up an XML file: remove issues from source data
    /// </summary>
    /// <param name="text"></param>
    /// <returns>Cleaned up file</returns>
    public static string CleanUpInputFile(string text)
    {
      text = text
        .ToLower()
        .Replace("&", "&amp;")
        .Replace("</span>", string.Empty)
        .Replace("</a>", string.Empty)
        .Replace("<p>", string.Empty); // issues found in input data XML files

      return Regex.Replace(text, @"[^\x20-\xD7FF\xE000-\xFFFD\x10000-x10FFFF]", string.Empty); // remove also tab and new line
    }

    /// <summary>
    /// Clean up XML inner text (review or title). Remove numbers and other characters not relevant for evaluation
    /// </summary>
    /// <param name="text"></param>
    /// <returns>Clean up text</returns>
    public static string CleanUpInnerText(string text)
    {
      return Regex.Replace(text, @"[^'a-z ,.;-]", string.Empty); // numbers and many other characters are not processed, keep delimiters and apostrophe
    }

    /// <summary>
    /// Clean up product name, format it
    /// </summary>
    /// <param name="productName"></param>
    /// <returns></returns>
    public static string CleanUpProductName(string productName)
    {
      productName = productName.Substring(0, Math.Min(productName.Length, 72));
      if (productName.Length == 72)
      {
        productName += " ...";
      }
      productName = productName.PadRight(76, ' ');

      return productName;
    }
  }
}
