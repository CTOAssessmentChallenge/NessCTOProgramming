﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCL
{
  class RankedProduct
  {
    public string Name;

    // calculated in SCLEvaluator
    public List<double> Ranks;
    public double RanksSum; // sum of all ranks

    public RankedProduct()
    {
      Name = string.Empty;
      Ranks = new List<double>();
      RanksSum = 0;
    }
  }
}
