﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace SCL
{
  class Program
  {
    static void Main(string[] args)
    {
      if (args.Length != 2)
      {
        Console.WriteLine("Usage: SCL <<training data dir>> <<test data file name>>" + Environment.NewLine);
        Console.WriteLine(" * Training data dir must contain three files: negative.review, positive.review and unlabeled.review.");
        Console.WriteLine(" * Both training and test data files must be stored in XML format, UTF8 , see  example data sets from");
        Console.WriteLine("   http://www.cs.jhu.edu/~mdredze/datasets/sentiment/index2.html ");
      }
      else
      {
        var trainingDataDir = args[0];
        var testDataFileName = args[1];
        var rankedWords = new List<RankedWord>();

        // train
        Console.WriteLine("Training phase started.");
        SCLTrainer.ReadTrainingData(Path.Combine(trainingDataDir, Constants.PositiveFileName), ref rankedWords);
        SCLTrainer.ReadTrainingData(Path.Combine(trainingDataDir, Constants.NegativeFileName), ref rankedWords);
        SCLTrainer.ReadTrainingData(Path.Combine(trainingDataDir, Constants.UnlabeledFileName), ref rankedWords);

        // calculate ranks
        Console.WriteLine("  Ranking words.");
        rankedWords = SCLTrainer.RankWords(rankedWords);

        // filter - rest of words will be ignored
        var mostNegativeWords = rankedWords.OrderBy(rw => rw.Rank).Take(Constants.PivotsCount).ToList();
        var mostPositiveWords = rankedWords.OrderByDescending(rw => rw.Rank).Take(Constants.PivotsCount).ToList();

        Console.WriteLine("Training phase ended.");

        // debug info
        Console.WriteLine(string.Format(Environment.NewLine + "[DEBUG] Most negative words: {0}", mostNegativeWords.Select(rw => rw.Word).Aggregate((i, j) => i + "," + j)));
        Console.WriteLine(string.Format("[DEBUG] Most positive words: {0}" + Environment.NewLine, mostPositiveWords.Select(rw => rw.Word).Aggregate((i, j) => i + "," + j)));

        // evaluate
        Console.WriteLine("Evaluation phase started.");
        var evaluationData = SCLEvaluator.ReadDataToEvaluate(testDataFileName);
        var rankedProducts = SCLEvaluator.EvaluateData(evaluationData, mostPositiveWords, mostNegativeWords);

        // output: evaluated products
        var bestProducts = rankedProducts.OrderByDescending(rp => rp.RanksSum).Take(Constants.ProductsCount).ToList();
        var worstProducts = rankedProducts.OrderBy(rp => rp.RanksSum).Take(Constants.ProductsCount).ToList();

        Console.WriteLine(Environment.NewLine + "  Best products by writer's attitude                                             Score");
        foreach (var product in bestProducts)
        {
          Console.WriteLine(string.Format("    {0} {1}", DataCleanUp.CleanUpProductName(product.Name), product.RanksSum.ToString("N3")));
        }
        Console.WriteLine(Environment.NewLine + "  Worst products by writer's attitude                                            Score");
        foreach (var product in worstProducts)
        {
          Console.WriteLine(string.Format("    {0} {1}", DataCleanUp.CleanUpProductName(product.Name), product.RanksSum.ToString("N3")));
        }

        Console.WriteLine(Environment.NewLine + "Evaluation phase ended.");
      }

      Console.ReadLine();
    }
  }
}
