﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;

namespace SCL
{
  static class SCLEvaluator
  {
    /// <summary>
    /// Read a file, clean up
    /// </summary>
    /// <param name="fileName"></param>
    /// <returns>File to be evaluated in string</returns>
    public static string ReadDataToEvaluate(string fileName)
    {
      Console.WriteLine(string.Format("  Reading data to evaluate from file {0}", fileName));
      string text = "<top>" + File.ReadAllText(fileName, Encoding.UTF8) + "</top>";

      return DataCleanUp.CleanUpInputFile(text);
    }

    /// <summary>
    /// Evaluate input file
    /// </summary>
    /// <param name="text"></param>
    /// <param name="mostPositiveWords"></param>
    /// <param name="mostNegativeWords"></param>
    /// <returns>List of ranked products (product names and its ranks)</returns>
    public static List<RankedProduct> EvaluateData(string text, List<RankedWord> mostPositiveWords, List<RankedWord> mostNegativeWords)
    {
      var rankedProducts = new List<RankedProduct>();

      XmlDocument xmlDoc = new XmlDocument();
      xmlDoc.LoadXml(text);
      XmlNodeList reviews = xmlDoc.SelectNodes(string.Format("//{0}", Constants.ReviewParentTag));

      foreach (XmlNode review in reviews)
      {
        var title = review[Constants.TitleTag]?.InnerText;
        var reviewText = review[Constants.ReviewTextTag]?.InnerText;
        var productName = review[Constants.ProductNameTag]?.InnerText;

        if (productName != null)
        {
          var titleEvaluation = title == null ? 0 : EvaluateSentence(title, mostPositiveWords, mostNegativeWords);
          var reviewTextEvaluation = reviewText == null ? 0 : EvaluateSentence(reviewText, mostPositiveWords, mostNegativeWords);

          var rankedProduct = rankedProducts.FirstOrDefault(rp => rp.Name == productName);

          if (rankedProduct == null)
          {
            // add, if not exists
            rankedProduct = new RankedProduct { Name = productName };
            rankedProducts.Add(rankedProduct);
          }

          var evaluatedValue = titleEvaluation * Constants.TitleRelevanceFactor + reviewTextEvaluation;
          rankedProduct.Ranks.Add(evaluatedValue); // will not be used, get ready for future enhancement
          rankedProduct.RanksSum += evaluatedValue;
        }
      }

      return rankedProducts;
    }

    /// <summary>
    /// Evaluate positivity of provided sentence (review text, or title)
    /// </summary>
    /// <param name="sentence"></param>
    /// <param name="mostPositiveWords"></param>
    /// <param name="mostNegativeWords"></param>
    /// <returns>higher number = more positive, lower number = more negative</returns>
    private static double EvaluateSentence(string sentence, List<RankedWord> mostPositiveWords, List<RankedWord> mostNegativeWords)
    {
      sentence = DataCleanUp.CleanUpInnerText(sentence);
      var words = sentence.Split(new char[] { ' ', ',', '.', ';' }, StringSplitOptions.RemoveEmptyEntries);

      if (words == null || words.Length == 0)
      {
        return 0;
      }

      var positiveWordCount = 0;
      var negativeWordCount = 0;
      foreach (var word in words)
      {
        if (mostPositiveWords.Any(w => w.Word == word))
        {
          positiveWordCount++;
        }

        if (mostNegativeWords.Any(w => w.Word == word))
        {
          negativeWordCount++;
        }
      }

      // Attitude about product is more positive, if it contains words from most positive words list
      // Attitude about product is more negative, if it contains words from most negative words list
      double positivity = positiveWordCount - negativeWordCount;

      // impact: consider total count of words - longer reviews should not have higher positivity / negativity
      double impact = 1.0D / words.Length;

      return positivity * impact;
    }
  }
}
