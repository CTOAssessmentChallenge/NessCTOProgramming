﻿using System;

namespace SCL
{
  class RankedWord
  {
    public string Word;

    public long PositiveWeightedCount;
    public long NegativeWeightedCount;
    public long TotalWeightedCount;
    
    // calculated in SCLTrainer
    public double Rank; 

    public RankedWord()
    {
      Word = string.Empty;
      PositiveWeightedCount = 0;
      NegativeWeightedCount = 0;
      TotalWeightedCount = 0;
      Rank = 0;
    }
  }
}
