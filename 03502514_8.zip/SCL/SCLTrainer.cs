﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

namespace SCL
{
  static class SCLTrainer
  {
    /// <summary>
    /// Read training data from input files
    /// </summary>
    /// <param name="fileName"></param>
    /// <param name="rankedWords">Ranked words - output</param>
    public static void ReadTrainingData(string fileName, ref List<RankedWord> rankedWords)
    {
      if (fileName.ToLower().EndsWith(Constants.PositiveFileName))
      {
        ReadTrainingData(fileName, 1, ref rankedWords);
      }
      else if (fileName.ToLower().EndsWith(Constants.NegativeFileName))
      {
        ReadTrainingData(fileName, -1, ref rankedWords);
      }
      else if (fileName.ToLower().EndsWith(Constants.UnlabeledFileName))
      {
        ReadTrainingData(fileName, 0, ref rankedWords);
      }
      else
      {
        throw new Exception("  File structure in training data incorrect.");
      }
    }

    /// <summary>
    /// Read training data from input file, clean up
    /// </summary>
    /// <param name="fileName"></param>
    /// <param name="positivityFactor"></param>
    /// <param name="rankedWords">Ranked words - output</param>
    private static void ReadTrainingData(string fileName, int positivityFactor, ref List<RankedWord> rankedWords)
    {
      Console.WriteLine(string.Format("  Reading training data from file {0}", fileName));
      string text = "<top>" + File.ReadAllText(fileName, Encoding.UTF8) + "</top>";

      text = DataCleanUp.CleanUpInputFile(text);

      XmlDocument xmlDoc = new XmlDocument();
      xmlDoc.LoadXml(text);
      XmlNodeList reviewTextsXmlNodes = xmlDoc.GetElementsByTagName(Constants.ReviewTextTag);
      List<string> reviewTexts = reviewTextsXmlNodes.Cast<XmlNode>().Select(x => x.InnerText).ToList();

      XmlNodeList titlesXmlNodes = xmlDoc.GetElementsByTagName(Constants.TitleTag);
      List<string> titles = titlesXmlNodes.Cast<XmlNode>().Select(x => x.InnerText).ToList();

      foreach (var sentence in reviewTexts)
      {
        RankSentence(sentence, positivityFactor, ref rankedWords);
      }

      foreach (var sentence in titles)
      {
        RankSentence(sentence, positivityFactor * Constants.TitleRelevanceFactor, ref rankedWords);
      }
    }

    /// <summary>
    /// Rank sentence (title ot review text)
    /// </summary>
    /// <param name="sentence"></param>
    /// <param name="positivityFactor"></param>
    /// <param name="rankedWords">Updated ranked words</param>
    private static void RankSentence(string sentence, int positivityFactor, ref List<RankedWord> rankedWords)
    {
      sentence = DataCleanUp.CleanUpInnerText(sentence);
      var words = sentence.Split(new char[] {' ', ',', '.', ';'}, StringSplitOptions.RemoveEmptyEntries);

      foreach (var word in words)
      {
        if (!IsMostCommonWord(word) && ContainsLetter(word))
        {
          var rankedWord = rankedWords.FirstOrDefault(rw => rw.Word == word);

          if (rankedWord == null)
          {
            // add, if not exists
            rankedWord = new RankedWord { Word = word };
            rankedWords.Add(rankedWord);
          }

          rankedWord.TotalWeightedCount++;
          if (positivityFactor > 0)
          {
            rankedWord.PositiveWeightedCount += positivityFactor;
          }
          if (positivityFactor < 0)
          {
            rankedWord.NegativeWeightedCount -= positivityFactor; // substract - keep positive numbers
          }
        }
      }
    }

    /// <summary>
    /// Check if word is among most common words in English
    /// </summary>
    /// <param name="word"></param>
    /// <returns></returns>
    public static bool IsMostCommonWord(string word)
    {
      if (Array.IndexOf(Constants.MostCommonWords, word) > -1)
      {
        return true;
      }

      return false;
    }

    /// <summary>
    /// Check if word contains at least one letter (ignore dashes, some forgotten delimiters, etc.)
    /// </summary>
    /// <param name="word"></param>
    /// <returns></returns>
    public static bool ContainsLetter(string word)
    {
      if (!string.IsNullOrEmpty(word))
      {
        for (var i = 0; i < word.Length; i++)
        {
          if (word[i] >= 'a' && word[i] <= 'z')
          {
            return true;
          }
        }
      }

      return false;
    }

    /// <summary>
    /// Calculate rank for each word in list of words
    /// </summary>
    /// <param name="rankedWords"></param>
    /// <returns>Updated ranked words</returns>
    public static List<RankedWord> RankWords(List<RankedWord> rankedWords)
    {
      foreach (var rankedWord in rankedWords)
      {
        // Word is more positive, if it is mentioned more frequently in positive file
        // Word is more negative, if it is mentioned more frequently in negative file
        double positivity = rankedWord.PositiveWeightedCount - rankedWord.NegativeWeightedCount;

        // Overall rank is more positive / negative, if it mentioned frequently in positive / negative files and less frequently in unlabeled
        // !!! if it is mentioned frequently in unlabeled, decrease impact
        double impact = ((double)(rankedWord.PositiveWeightedCount + rankedWord.NegativeWeightedCount)) / rankedWord.TotalWeightedCount; // total includes unlabeled

        rankedWord.Rank = positivity * impact;
      }

      return rankedWords;
    }
  }
}
