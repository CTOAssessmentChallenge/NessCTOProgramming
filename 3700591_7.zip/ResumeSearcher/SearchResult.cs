﻿namespace ResumeSearcher
{
    public class SearchResult
    {
        public string FileName;
        public string FilePath;
    }
}
