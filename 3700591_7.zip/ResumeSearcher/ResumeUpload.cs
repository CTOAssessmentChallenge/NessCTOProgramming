﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using Novacode;
using Tesseract;
using Path = System.IO.Path;

namespace ResumeSearcher
{
    /**
     * 
     * Because of max file size limit of 2MB
     * before building, and running the code, 
     * you have to Uninstall the "Tesseract" library using the NuGet Package Manager,
     * then install it again, version 3.0.2    
     *  
     */

    public partial class frmResumeUpload : Form
    {
        private readonly int MIN_SEARCH_LENGTH = 2;
        private readonly string workingDirectoryPath = @"C:\temp";
        private BackgroundWorker docxSearchWorker;
        private BackgroundWorker pdfSearchWorker;
        private BackgroundWorker imgSearchWorker;

        public frmResumeUpload()
        {
            InitializeComponent();

            docxSearchWorker = new BackgroundWorker
            {
                WorkerSupportsCancellation = true
            };
            docxSearchWorker.DoWork += DocxSearchWorker_DoWork;
            docxSearchWorker.RunWorkerCompleted += DocxSearchWorker_RunWorkerCompleted;

            pdfSearchWorker = new BackgroundWorker
            {
                WorkerSupportsCancellation = true
            };
            pdfSearchWorker.DoWork += PdfSearchWorker_DoWork;
            pdfSearchWorker.RunWorkerCompleted += PdfSearchWorker_RunWorkerCompleted;

            imgSearchWorker = new BackgroundWorker
            {
                WorkerSupportsCancellation = true
            };
            imgSearchWorker.DoWork += ImgSearchWorker_DoWork;
            imgSearchWorker.RunWorkerCompleted += ImgSearchWorker_RunWorkerCompleted;
        }

        private void ImgSearchWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            var searchText = (string)e.Argument;
            var result = new List<SearchResult>();
            var directory = new DirectoryInfo(workingDirectoryPath);
            var files = directory.GetFilesByExtensions(".jpg", ".png", ".bmp").Where(f => !f.Attributes.HasFlag(FileAttributes.Hidden));

            foreach (var file in files)
            {
                if (SearchImg(file.FullName, searchText))
                {
                    result.Add(new SearchResult
                    {
                        FileName = Path.GetFileName(file.Name),
                        FilePath = file.FullName
                    });
                }
            }

            e.Result = result;
        }

        private void PdfSearchWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            var searchText = (string)e.Argument;
            var result = new List<SearchResult>();
            var directory = new DirectoryInfo(workingDirectoryPath);
            var files = directory.GetFiles("*.pdf").Where(f => !f.Attributes.HasFlag(FileAttributes.Hidden));

            foreach (var file in files)
            {
                if (SearchPdf(file.FullName, searchText))
                {
                    result.Add(new SearchResult
                    {
                        FileName = Path.GetFileName(file.Name),
                        FilePath = file.FullName
                    });
                }
            }

            e.Result = result;
        }

        private void DocxSearchWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            var searchText = (string) e.Argument;
            var result = new List<SearchResult>();
            var directory = new DirectoryInfo(workingDirectoryPath);
            var files = directory.GetFiles("*.docx").Where(f => !f.Attributes.HasFlag(FileAttributes.Hidden));
            
            foreach (var file in files)
            {
                if (SearchDocx(file.FullName, searchText))
                {
                    result.Add(new SearchResult
                    {
                        FileName = Path.GetFileName(file.Name),
                        FilePath = file.FullName
                    });
                }
            }

            e.Result = result;
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.InitialDirectory = "c:\\";
            openFileDialog.Filter = @"Word Documents|*.docx" +
             @"|Image Files|*.jpg;*.png;*.bmp" + @"|PDF Files|*.pdf";
            openFileDialog.FilterIndex = 1;
            openFileDialog.RestoreDirectory = false;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    Stream myStream = null;
                    if ((myStream = openFileDialog.OpenFile()) != null)
                    {
                        using (myStream)
                        {
                            using (var fileStream = File.Create(String.Format("C:\\temp\\{0}", Path.GetFileName(openFileDialog.FileName))))
                            {
                                myStream.Seek(0, SeekOrigin.Begin);
                                myStream.CopyTo(fileStream);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtSearch.Text.Length < MIN_SEARCH_LENGTH)
            {
                MessageBox.Show(string.Format("Enter at least {0} search characters", MIN_SEARCH_LENGTH));

                return;
            }

            resultView.Items.Clear();
            btnSearch.Enabled = false;
            btnStop.Enabled = true;

            if (docxSearchWorker.IsBusy != true)
            {
                docxSearchWorker.RunWorkerAsync(txtSearch.Text);
            }

            if (pdfSearchWorker.IsBusy != true)
            {
                pdfSearchWorker.RunWorkerAsync(txtSearch.Text);
            }

            if (imgSearchWorker.IsBusy != true)
            {
                imgSearchWorker.RunWorkerAsync(txtSearch.Text);
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            if (docxSearchWorker.IsBusy && docxSearchWorker.WorkerSupportsCancellation)
            {
                docxSearchWorker.CancelAsync();
            }

            if (pdfSearchWorker.IsBusy && pdfSearchWorker.WorkerSupportsCancellation)
            {
                pdfSearchWorker.CancelAsync();
            }
        }

        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnSearch.PerformClick();
            }
        }

        private void DocxSearchWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                MessageBox.Show(e.Error.Message);
            }
            else if (e.Cancelled == false)
            {
                var result = e.Result as List<SearchResult>;
                if (result != null)
                {
                    result.ForEach(i => resultView.Items.Add(new ListViewItem(i.FileName)
                    {
                        Tag = i.FilePath
                    }));
                }
            }

            CheckBackgroundWorkers();
        }

        private void PdfSearchWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                MessageBox.Show(e.Error.Message);
            }
            else if (e.Cancelled == false)
            {
                var result = e.Result as List<SearchResult>;
                if (result != null)
                {
                    result.ForEach(i => resultView.Items.Add(new ListViewItem(i.FileName)
                    {
                        Tag = i.FilePath
                    }));
                }
            }

            CheckBackgroundWorkers();
        }

        private void ImgSearchWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                MessageBox.Show(e.Error.Message);
            }
            else if (e.Cancelled == false)
            {
                var result = e.Result as List<SearchResult>;
                if (result != null)
                {
                    result.ForEach(i => resultView.Items.Add(new ListViewItem(i.FileName)
                    {
                        Tag = i.FilePath
                    }));
                }
            }

            CheckBackgroundWorkers();
        }

        private void CheckBackgroundWorkers()
        {
            if (docxSearchWorker.IsBusy || pdfSearchWorker.IsBusy || imgSearchWorker.IsBusy)
            {
                btnStop.Enabled = true;
                btnSearch.Enabled = false;
                return;
            }

            btnStop.Enabled = false;
            btnSearch.Enabled = true;
        }

        private bool isMatch(string text, string searchString, bool caseSensitive = false)
        {
            return text.IndexOf(searchString, caseSensitive ? 
                    StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private bool SearchDocx(string filePath, string searchString)
        {
            try
            {
                if (!File.Exists(filePath))
                {
                    return false;
                }

                using (var fileStream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    using (var document = DocX.Load(fileStream))
                    {
                        return isMatch(document.Text, searchString);
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        private bool SearchPdf(string filePath, string searchString)
        {
            try
            {
                if (!File.Exists(filePath))
                {
                    return false;
                }

                var pdfReader = new PdfReader(filePath);
                var textFound = false;

                for (int page = 1; page <= pdfReader.NumberOfPages; page++)
                {
                    var currentPageText = PdfTextExtractor.GetTextFromPage(pdfReader, page,
                        new SimpleTextExtractionStrategy());

                    if (isMatch(currentPageText, searchString))
                    {
                        textFound = true;
                        break;
                    }
                }

                pdfReader.Close();

                return textFound;
            }
            catch(Exception)
            {
                return false;
            }
        }

        private bool SearchImg(string filePath, string searchString)
        {
            try
            {
                if (!File.Exists(filePath))
                {
                    return false;
                }

                using (var engine = new TesseractEngine(@"./tessdata", "eng", EngineMode.Default))
                {
                    using (var img = Pix.LoadFromFile(filePath))
                    {
                        using (var page = engine.Process(img))
                        {
                            var text = page.GetText();

                            return isMatch(text, searchString);
                        }
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        
    }
}
